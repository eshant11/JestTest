import React from 'react'

function Home() {
  return (
    <div className='className'>Home</div>
  )
}

export default Home