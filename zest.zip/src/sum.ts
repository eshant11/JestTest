import React from 'react'

// function sum(a:number,b:number) {

//   return a+b;
// }
function obj() {

  return {name:"Eshant"};
}



// module.exports= sum;
module.exports= obj;